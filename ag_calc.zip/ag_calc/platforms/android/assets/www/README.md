# ag_calc
Agricultural based calculator with specific functions designed to aid those in the farming industry.

# To Git
//to download  
git clone https://github.com/aaaelite21/ag_calc.git  
//once you are done editing the code  
git checkout -b (branch name)  
git add .  
git commit -m (string of the changed you made)  
git push -u origin (branch name)  
//let me know you pushed the files  
