//define reused element variables
//action buttons
var view = $("#view");
var clear = $(".clear");
var menuButton = $(".menuButton");
var dec = $(".dec");
var del = $(".delete");
var equal = $(".equal");

//operation buttons
var add = $(".add");
var sub = $(".sub");
var mul = $(".mul");
var div = $(".div");
var perL = $(".perrenL");
var perR = $(".perrenR");
var power = $(".pow");

// design objects
var work = $("#workSpace");
var menu = $("#menu");
var disp = $("#displayWindow");

// Calc displays
var normal = $("#normalCalc");
var scientific = $("#scientficCalc");
var wrapper = $("#wrapper");

//numbered buttons
var num1 = $(".num1");
var num2 = $(".num2");
var num3 = $(".num3");
var num4 = $(".num4");
var num5 = $(".num5");
var num6 = $(".num6");
var num7 = $(".num7");
var num8 = $(".num8");
var num9 = $(".num9");
var num0 = $(".num0");

//define the memory variables used when
//performing arathmatic
var decimal = false;
var agitated = false;

//run when the application loads
window.onload = function() {
    resizeScreenText();
    createList();
    for (var i = 0; i < functionList.length; i++) {
        menu.append("<span id='" +
            i + "fun'>" + functionList[i].name + "</span><br/><br/>");

        //i does not pass from the for loop to the jquery for some reason
        document.getElementById(i + 'fun').onclick = function() {
            functionList[parseInt(this.id)].draw();
            if (disp.css("display") == "none") {
                disp.show();
            }
        }
    }

}

//run when screen is rotated
window.onresize = function() {
    resizeScreenText();
}

//Function to add the desired character to the s
//viewing window string
function write(x) {
    if (view.html() != "" && !agitated && view.html() != "0") {
        view.append(x);
        if (x == ".") {
            decimal == true;
        }
    } else if (agitated) {
        if (x == "-" || x == "+" || x == "x" || x == "/" || x == "^") {
            view.append(x);
        } else if (x != ".") {
            view.html(x)
            decimal = false;
        } else if (x == ".") {
            view.html("0.");
            decimal = true;
        }
        agitated = false;
    } else if (view.html() == "") {
        if (x != "+" && x != "x" && x != "/" || x == "^") {
            if (x == ".") {
                view.html("0.");
                decimal = true;
            } else {
                view.html(x)
                decimal = false;
            }
        }
    } else {
        view.html(x);
        decimal = false;
    }
    //shrinks text if need be
    keepNeat();
}


//assign the write function to its respective IDS
perL.click(function() {
    write("(");
});
perR.click(function() {
    write(")");
});
num1.click(function() {
    write("1");
});
num2.click(function() {
    write("2");
});
num3.click(function() {
    write("3");
});
num4.click(function() {
    write("4");
});
num5.click(function() {
    write("5");
});
num6.click(function() {
    write("6");
});
num7.click(function() {
    write("7");
});
num8.click(function() {
    write("8");
});
num9.click(function() {
    write("9");
});
num0.click(function() {
    if (view.html() != "0")
        write("0");
});
dec.click(function() {
    if (!decimal) {
        write(".");
    }
});
del.click(function() {
    if (view.html() != "") {
        var temp = view.html();
        view.html(temp.substring(0, temp.length - 1));
        if (temp.substring(temp.length - 1, temp.length) == ".")
            decimal = false;
    }
});
equal.click(function() {
    if (view.html() != "")
        equate();
});
add.click(function() {
    if (view.html() != "" && goodChar(0)) {
        write("+");
    }
});
sub.click(function() {
    if (goodChar(0)) {
        write("-");
    } else if (goodChar(1) && view.html().length > 1) {
        write("-");
    }
});
mul.click(function() {
    if (view.html() != "" && goodChar(0)) {
        write("x");
    }
});
power.click(function() {
    if (view.html() != "" && goodChar(0)) {
        write("^");
    }
});
div.click(function() {
    if (view.html() != "" && goodChar(0)) {
        write("/");
    }
});

//function for the clear view
clear.click(function() {
    view.html("");
    decimal = false;
    agitated = false;
    keepNeat();
});

//function to adjust the displays text
//size when the window is loaded or rotated
function resizeScreenText() {
    var height = view.height();
    view.css("font-size", parseInt((height / 2)).toString() + "px");
    view.css("line-height", parseInt((height)).toString() + "px");
    if (wrapper.width() > wrapper.height()) {
        normal.hide();
        scientific.show();
    } else {
        scientific.hide();
        normal.show();
    }
}

//show menue when clicked
menuButton.click(function() {
    work.show();
    menu.slideDown("slow", function() {
        //function completion to come
    });
});

//hide menu when clicked
work.click(function() {
    work.hide();
    if (disp.css("display") != "none") {
        disp.hide();
    }
    menu.slideUp("slow", function() {
        //function completion to come
    });
});

//check the last char of the view to see if it
//is a a non-number character
function goodChar(number) {
    var temp;
    var go = true;
    for (var i = 0; i < 4; i++) {
        temp = view.html().substring(view.html().length - 1 - number, view.html().length - number);
        if (temp == "+" ||
            temp == "." ||
            temp == "-" ||
            temp == "x" ||
            temp == "/") {
            go = false;
            break;
        }
    }
    return go;
}

//function to get an answer from the input
function equate() {
    var lastOpp = 0;
    var str = view.html();
    var strArray = str.split("");
    console.log(strArray);
    var nums = new Array();
    //add = 1, sub = 2, mul = 3, div = 4
    var opps = new Array();

    //temp variable to be used to check the variable for NaN
    var temp;

    for (var i = 0; i < strArray.length; i++) {
        //will need adjusted for other opperands
        if (strArray[i] == "+" && i != strArray.length - 1) {
            temp = parseFloat(str.substring(lastOpp, i + 1));
            if (!isNaN(temp)) {
                nums.push(temp);
            }
            opps.push(1);
            lastOpp = i + 1;
        } else if (strArray[i] == "-" && i != 0 && i != strArray.length - 1) {
            temp = parseFloat(str.substring(lastOpp, i + 1));
            if (!isNaN(temp)) {
                nums.push(temp);
            }
            opps.push(2);
            lastOpp = i + 1;
        } else if ((strArray[i] == "x" || strArray[i] == "X") && i != strArray.length - 1) {
            temp = parseFloat(str.substring(lastOpp, i + 1));
            if (!isNaN(temp)) {
                nums.push(temp);
            }
            opps.push(3);
            lastOpp = i + 1;
        } else if (strArray[i] == "/" && i != strArray.length - 1) {
            temp = parseFloat(str.substring(lastOpp, i + 1));
            if (!isNaN(temp)) {
                nums.push(temp);
            }
            opps.push(4);
            lastOpp = i + 1;
        } else if (strArray[i] == "(" && i != strArray.length - 1) {
            temp = parseFloat(str.substring(lastOpp, i + 1));
            if (!isNaN(temp)) {
                nums.push(temp);
            }
            opps.push(5);
            lastOpp = i + 1;
        } else if (strArray[i] == ")" && i != strArray.length - 1) {
            temp = parseFloat(str.substring(lastOpp, i + 1));
            if (!isNaN(temp)) {
                nums.push(temp);
            }
            opps.push(6);
            lastOpp = i + 1;
        } else if (strArray[i] == "^" && i != strArray.length - 1) {
            temp = parseFloat(str.substring(lastOpp, i + 1));
            if (!isNaN(temp)) {
                nums.push(temp);
            }
            opps.push(7);
            lastOpp = i + 1;
        } else if (i == strArray.length - 1) {
            if (strArray[i] == ")") {
                opps.push(6);
                var tester = parseFloat(str.substring(lastOpp, i));
                if (!isNaN(tester))
                    nums.push(tester);
            } else {
                var tester = parseFloat(str.substring(lastOpp, i + 1));
                if (!isNaN(tester))
                    nums.push(tester);
            }
        }
        //the below might be left over useless code form
        //a time in development long forgoten...
        if (i + 1 == nums.length) {
            break;
        }

    }


    view.html(doTheMath(nums, opps));
    agitated = true;
    //resets the view text size
    resizeScreenText();
    keepNeat();
    decimal = false;
}

// recursive function to do the math
function doTheMath(num, op) {
    // inatlize the variables
    var R0;
    var R1;
    var temp;
    //number of times an elemnt has been removed
    var numberOfCuts = 0;
    var mulAndDivision = new Array();
    var perren = new Array();
    var powers = new Array();
    // attempt at PEMDAS
    if (op.length >= 1) {
        for (var i = 0; i < op.length; i++) {
            if (op[i] == 3 || op[i] == 4) {
                mulAndDivision.push(i);
            } else if (op[i] == 5 || op[i] == 6) {
                perren.push(i);
            } else if (op[i] == 7) {
                powers.push(i);
            }
        }
    }

    // do special orders first
    if (op.length > 1 && num.length > 1) {
        //perrenthies
        if (perren.length > 0) {
            //location of first perren
            var firstPerren;
            var lastPerren;
            var count = 0;
            for (var j = 0; j < perren.length; j++) {
                if (op[perren[j] - numberOfCuts] == 5) {
                    if (count == 0) {
                        firstPerren = perren[j] - numberOfCuts;
                    }
                    count++;
                } else if (op[perren[j] - numberOfCuts] == 6) {
                    count--;
                    lastPerren = perren[j] - numberOfCuts;
                }
                if (count == 0) {
                    //recursavily call the doTheMathFunction
                    //
                    //create smaller arrays to feed into recursion
                    var reNum = num.slice(firstPerren, lastPerren);
                    var reOp = op.slice(firstPerren + 1, lastPerren);
                    //adjust nums according to recursive output
                    num.splice(firstPerren, lastPerren - firstPerren, doTheMath(reNum, reOp));
                    //remove used ops
                    op.splice(firstPerren, lastPerren + 1 - firstPerren)
                    numberOfCuts += (lastPerren - firstPerren) + 1;
                }
            }
        }

        if (powers.length > 0 && op.length > 0) {
            for (var i = 0; i < powers.length; i++) {
                R1 = num[powers[i - numberOfCuts]];
                R0 = num[powers[i - numberOfCuts] + 1];
                temp = Math.pow(R1, R0);
                num.splice(powers[i - numberOfCuts], 2, temp);
                op.splice(powers[i - numberOfCuts], 1);
                numberOfCuts++;
            }
        }

        if (mulAndDivision.length > 0 && op.length > 0) {
            numberOfCuts = 0;
            for (var i = 0; i < mulAndDivision.length; i++) {
                R1 = num[mulAndDivision[i - numberOfCuts]];
                R0 = num[mulAndDivision[i - numberOfCuts] + 1];
                if (op[mulAndDivision[i - numberOfCuts]] == 3) {
                    temp = R1 * R0;
                } else if (op[mulAndDivision[i - numberOfCuts]] == 4) {
                    temp = R1 / R0;
                } //if op is a parenthisies
                //cuts the numbers that were used and then
                //adds in the answer
                num.splice(mulAndDivision[i - numberOfCuts], 2, temp);
                op.splice(mulAndDivision[i - numberOfCuts], 1);
                numberOfCuts++;
            }
        }
    }
    // when there is one or more number remaining after all
    // but addition and subtraction is done
    // or if there is only one opperation
    while (num.length > 1) {
        R0 = num[0];
        R1 = num[1];
        //1000 are a temparary fix for the float issue
        //looking into using Number() to solve problem
        if (op[0] == 1) {
            temp = (R0 * 1000 + R1 * 1000) / 1000;
        } else if (op[0] == 2) {
            temp = (R0 * 1000 - R1 * 1000) / 1000;
        } else if (op[0] == 3) {
            temp = R0 * R1;
        } else if (op[0] == 4) {
            temp = R0 / R1;
        }else if (op[0] == 7){
          temp = Math.pow(R0,R1);
        }
        num.splice(0, 2, temp);
        op.splice(0, 1);
    }

    return num[0];

} //end do the math

//function to check for overflow and
//adjust the size of teh text in the
//viewing window
function keepNeat() {

    //current code infinate loops for some reason
    /*  if (view.prop('scrollWidth') > view.width()) {
            while (view.prop('scrollWidth') > view.width()) {
                var newSize = parseInt(view.css("font-size")) - 1;
                view.css("font-size", (newSize + "px"));
            }
        }*/
}
