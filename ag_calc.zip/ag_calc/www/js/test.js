//This fi;e is not needed for actual release

//functiion designed to test the math function
//of the calculator
function mathTest() {
    var ans = 0.0;
    //get the test div object
    var tester = $('#test');
    tester.show();
    //basic addidion
    tester.append("x + y  ");
    if (doTheMath([2, 3], [1]) == 5) {
        tester.append("passed<br/>")
    } else {
        tester.append("failed<br/>")
    }
    //basic subtraction
    tester.append("x - y  ");
    if (doTheMath([2, 3], [2]) == -1) {
        tester.append("passed<br/>")
    } else {
        tester.append("failed<br/>")
    }
    //basic multiplication
    tester.append("x * y  ");
    if (doTheMath([2, 3], [3]) == 6) {
        tester.append("passed<br/>")
    } else {
        tester.append("failed<br/>")
    }
    //basic division
    tester.append("x / y  ");
    if (doTheMath([4, 2], [4]) == 2) {
        tester.append("passed<br/>")
    } else {
        tester.append("failed<br/>")
    }
    //basic perren
    tester.append("(x op y)  ");
    if (doTheMath([2, 3], [5, 1, 6]) == 5) {
        tester.append("passed<br/>")
    } else {
        tester.append("failed<br/>")
    }
    //encased perren
    tester.append("((x opp y))  ");
    if (doTheMath([2, 3], [5, 5, 1, 6, 6]) == 5) {
        tester.append("passed<br/>")
    } else {
        tester.append("failed<br/>")
    }
    //perrens after opp
    tester.append("a op (x op Y) ");
    if (doTheMath([2, 2, 3], [3, 5, 1, 6]) == 10) {
        tester.append("passed<br/>")
    } else {
        tester.append("failed<br/>")
    }
    //sequencial perren
    tester.append("(x op Y) op (a op b) ");
    if (doTheMath([2, 3, 2, 3], [5, 1, 6, 2, 5, 1, 6]) == 0) {
        tester.append("passed<br/>")
    } else {
        tester.append("failed<br/>")
    }
    //mystery broken
    tester.append("5+5+(5+5)*10 ");
    ans=doTheMath([5,5,5,5,10], [1,1,5,1,6,3])
    if (ans == 110) {
        tester.append("passed<br/>")
    } else {
        tester.append("failed with:" + ans + "<br/>")
    }

    //2^2
    tester.append("2^2 ");
    if (doTheMath([2,2], [7]) == 4) {
        tester.append("passed<br/>")
    } else {
        tester.append("failed<br/>")
    }
    //2^4
    tester.append("2^4 ");
    if (doTheMath([2,4], [7]) == 16) {
        tester.append("passed<br/>")
    } else {
        tester.append("failed<br/>")
    }
    //5*2^4
    tester.append("5 * 2^4 ");
    if (doTheMath([5,2,4], [3,7]) == 80) {
        tester.append("passed<br/>")
    } else {
        tester.append("failed<br/>")
    }
}
