//File contains all the functions we needed by the
//client in order to preform day to day agricultural
//actavaties with ease
var functionList = new Array();
//liquid chemicla calculator
function createList() {
    functionList.push({
        //the name of the function
        name: "Volume Chemical Calculator",
        //edit this to your liking. It has to be on one line to i recomend editing it in its own HTML Doc
        myHTML: `<input class='chemInput ci1' type='number' id='input1' />
          <input class='chemInput ci2' type='number' id='input2' />
          <select class='chemSelect cs1' id='select1'>
                <option value='floz'>floz</option>
                <option value='gal'>Gal</option>
                <option value='tbs'>TBS</option>
                <option vlaue="cups">Cups</option>
             </select>
          <div class="chemDivider"></div>
          <select class='chemSelect cs2' id='select2'>
              <option value='Acre'>Acre</option>
              <option value='sqrfeet'>Sqr Feet</option>
             </select>
          <input class='chemInput ci3' type='number' id='input3' />
          <select class='chemSelect cs3' id='select3'>
              <option value='acre'>Acre</option>
              <option value='sm'>Sqr Miles</option>
              <option value='sf'>Sqr Feet</option>
              <option value='skm'>Sqr Kilometer</option>
              <option value='m2'>Sqr Meters</option>
             </select>
          <button class="chemButton" id='button'>Submit</button><br/><br/>
          <div id='chemAnswer'></div>`,
        draw: function() {
            disp.html(this.myHTML);
            $("#button").click(function() {
                //relevent liquid units according to labesl
                //in relation to litter
                const fluid_ounces_per_liter = 33.814;
                const gallons_per_liter = 0.264172;
                const tbs_per_liter = 67.628;
                const cups_per_liter = 4.22675;

                //relavent area unitsd
                const acres_per_m2 = 4046.86;
                const f2_per_m2 = 10.7639;
                const km2_per_m2 = 1000000;
                const m2_per_miles2 = 2590000;

                //get the values of the inputs you need from the user
                //using document.getElementById(idName)
                var input1 = parseFloat(document.getElementById('input1').value);
                var input2 = parseFloat(document.getElementById('input2').value);
                var input3 = parseFloat(document.getElementById('input3').value);

                //get the unit option from the user
                var unitInput1 = document.getElementById('select1').value;
                var unitInput2 = document.getElementById('select2').value;
                var unitInput3 = document.getElementById('select3').value;

                var answer = 0.0;
                var answerUnit = " L"

                //get volume inliters
                if (unitInput1 == "floz") {
                    input1 = input1 / fluid_ounces_per_liter;
                } else if (unintInput1 == "tbs") {
                    input1 = input1 * tbs_per_liter;
                } else if (unintInput1 == "gal") {
                    input1 = input1 / gallons_per_liter;
                } else if (unintInput1 == "cups") {
                    input1 = input1 * cups_per_liter;
                }


                console.log("input 1: " + input1);

                //get area one into m2
                if (unitInput2 == "sqrfeet") {
                    input2 = input2 / f2_per_m2;
                } else {
                    input2 = input2 * acres_per_m2;
                }

                console.log("input2: " + input2);

                //get field area into m2
                if (unitInput3 == "acre") {
                    input3 = input3 * acres_per_m2;
                } else if (unitInput3 == "sf") {
                    input3 = input3 / f2_per_m2;
                } else if (unitInput3 == "skm") {
                    input3 = input3 * km2_per_m2;
                } else if (unitInput3 == "sm") {
                    input3 = input3 * m2_per_miles2;
                }

                console.log("input3: " + input3);

                //scale answer by bottom number
                answer = input1 * (input3 / input2);

                if (answer < 1) {
                    answer *= 1000;
                    answerUnit = " mL"
                }


                // code to display answer to the user
                // use + "" to add units if needed
                document.getElementById('chemAnswer').innerHTML = answer.toFixed(5) + answerUnit;
            });

        }
    });
    //mass chemical calculator
    functionList.push({
        //the name of the function
        name: "Mass Chemical Calculator",
        //edit this to your liking. It has to be on one line to i recomend editing it in its own HTML Doc
        myHTML: `<input class='chemInput ci1' type='number' id='input1' />
              <input class='chemInput ci2' type='number' id='input2' />
              <select class='chemSelect cs1' id='select1'>
                    <option value='g'>grams</Gal</option>
                    <option value='oz'>Ounces</Gal</option>
                    <option value='lbs'>Pounds</Gal</option>
                 </select>
              <div class="chemDivider"></div>
              <select class='chemSelect cs2' id='select2'>
                  <option value='Acre'>Acre</option>
                  <option value='sqrfeet'>Sqr Feet</option>
                 </select>
              <input class='chemInput ci3' type='number' id='input3' />
              <select class='chemSelect cs3' id='select3'>
                  <option value='Acre'>Acre</option>
                  <option value='sm'>Sqr Miles</option>
                  <option value='sf'>Sqr Feet</option>
                  <option value='skm'>Sqr Kilometer</option>
                  <option value='sm'>Sqr Meters</option>
                 </select>
              <button class="chemButton" id='button'>Submit</button><br/><br/>
              <div id='chemAnswer'></div>`,
        draw: function() {
            disp.html(this.myHTML);
            $("#button").click(function() {
                //units
                var answer = 0.0;
                var answerUnit = " L"


                //1 unit per gallon
                const grams_per_ounces = 28.3498;
                const grams_per_pound = 453.592;

                //get the values of the inputs you need from the user
                //using document.getElementById(idName)
                var input1 = parseFloat(document.getElementById('input1').value);
                var input2 = parseFloat(document.getElementById('input2').value);
                var input3 = parseFloat(document.getElementById('input3').value);

                //get the unit option from the user
                var unitInput1 = document.getElementById('select1').value;
                var unitInput2 = document.getElementById('select2').value;
                var unitInput3 = document.getElementById('select3').value;

                var answer = 0.0;
                var answerUnit = " L";

                if (unitInput1 == "oz") {
                    input1 = input1 * grams_per_ounces;
                } else if (unitInput1 == "lbs") {
                    input1 = input1 * grams_per_pound;
                }

                //get field area into m2
                if (unitInput3 == "acre") {
                    input3 = input3 * acres_per_m2;
                } else if (unitInput3 == "sf") {
                    input3 = input3 / f2_per_m2;
                } else if (unitInput3 == "skm") {
                    input3 = input3 * km2_per_m2;
                } else if (unitInput3 == "sm") {
                    input3 = input3 * m2_per_miles2;
                }
                //scale answer by bottom number
                answer = input1 * (input3 / input2);

                if (answer < 1) {
                    answer *= 1000;
                    answerUnit = " mg"
                }


                // code to display answer to the user
                // use + "" to add units if needed
                document.getElementById('chemAnswer').innerHTML = answer.toFixed(5) + answerUnit;

            });
        }
    });


    //mapping function below
    functionList.push({
        //the name of the function
        name: "Field Mapping",
        //edit this to your liking. It has to be on one line to i recomend editing it in its own HTML Doc
        myHTML: `
        <button class="GPSButton" id="button">Take Points</button><br><br>
        <div id="data2"></div><br/><br/>
        <button class="GPSButton" id="areaButton">Get Area</button><br><br>
        <div id="data3"></div>`,
        //the draw function defines the onclick function as well as
        //draws the name of the function in the menu bar
        draw: function() {
            disp.html("<h3>" + this.name + "</h3>" + this.myHTML);
            // Array set to contain the lat and lon position of the user when the button is pressed
            var y = new Array();
            var x = new Array();
            $("#button").click(function() {
                //liams code below
                document.addEventListener("deviceready", onDeviceReady, false);

                function onDeviceReady() {
                    console.log("navigator.geolocation works well");
                }
                // onSuccess Callback
                // This method accepts a Position object, which contains the
                // current GPS coordinates
                //
                var onSuccess = function(position) {
                    y.push(position.coords.latitude);
                    x.push(position.coords.longitude);
                    var logger2 = "";
                    for (i = 0; i < x.length; i++) {
                        logger2 += "(" + x[i] + " , " + y[i] + ")<br/>";
                    }
                    $('#data2').html(logger2);
                };


                // onError Callback receives a PositionError object
                function onError(error) {
                    alert("code: " + error.code + "\n" +
                        "message: " + error.message + "\n");
                }

                navigator.geolocation.getCurrentPosition(onSuccess, onError);

            });
            $("#areaButton").click(function() {
              //ensure there are at least 3 points
                if (x.length > 2) {
                    //convert to Meters
                    //find smallest lat and biggest lon
                    //to make origin point
                    var smallesty = y[0];
                    var smallestx = x[0];
                    var i;
                    for (i = 1; i < x.length; i++) {
                        if (y[i] < smallesty) {
                            smallesty = y[i];
                        }
                        if (x[i] < smallestx) {
                            smallestx = x[i];
                        }
                    }
                    //now that we have origin point we need to
                    //actually convert everything into Meters
                    //in a local x,y graph
                    var R = 6378.137; //rad of earth in Meters
                    var dLat;
                    var dLon;
                    var a;
                    var c;
                    var d;
                    var holder;
                    for (i = 0; i < x.length; i++) {
                        //distance from 0 on x axis to same y value is the
                        //new x value in Meters
                        dLat = 0;
                        dLon = (x[i] - smallestx) * Math.PI / 180;
                        a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(y[i] * Math.PI / 180) * Math.cos(y[i] * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
                        c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
                        d = R * c;
                        holder = d * 1000; // meters
                        //distance from 0 on y axis to same x value is the
                        //new y value in Meters
                        dLat = (y[i] - smallesty) * Math.PI / 180;
                        dLon = 0;
                        a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(smallesty * Math.PI / 180) * Math.cos(y[i] * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
                        c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
                        d = R * c;
                        y[i] = parseInt(d * 1000); // meters
                        x[i] = parseInt(holder);
                    }

                    //code to get the area
                    var area = 0;
                    var j = x.length - 1;
                    for (i = 0; i < x.length; i++) {
                        area += ((x[j] + x[i]) * (y[j] - y[i]));
                        j = i;
                    }
                    //output area to workplace
                    area = Math.abs(area * 0.5);
                    $("#data3").html(area + " m<sup>2</sup>");
                    //code to draw field on canvas
                    //
                    //code to rest w/o GPS
                  //  x = [0, 60, 50];
                  //  y = [100, 0, 75];

                    //end test code
                    var w = parseInt(disp.width()) - 10;
                    var h = "400px";
                    disp.append(`<center><canvas id="field" width="`+ w +`" height="`+ h +`"></canvas></center>`)
                    //code to draw map
                    var c = document.getElementById('field');
                    var ctx = c.getContext("2d");
                    ctx.fillStyle = "#000";
                    ctx.fillRect(0,0, w, 400);
                    ctx.moveTo(x[0],y[0]);
                    for(i = 1; i < x.length; i++){
                      //h-y[z] so that 0,0 is the bottom left corner
                      ctx.lineTo(x[i], y[i]);
                    }
                    ctx.closePath();
                    ctx.fillStyle = "#fff";
                    ctx.fill();
                }
            });
        }
    });
}
